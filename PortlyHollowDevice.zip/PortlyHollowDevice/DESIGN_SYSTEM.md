# SpendPrint AI 2.0 design system

## Visual language

SpendPrint uses a light, analytical workspace with a warm-white canvas, quiet blue-grey text, violet model accents, and teal observed-signal accents. Violet is used for model and navigation focus; teal is reserved for data that is connected or healthy.

## Type

Manrope provides the primary UI voice. DM Mono is used for model metric values and compact technical labels. Uppercase eyebrow labels use wide tracking to support scanability.

## Layout

The desktop shell uses a 252px persistent sidebar and a centered content rail. Cards use 12px radius, 1px low-contrast borders, and restrained shadows only on primary actions. The layout collapses to a slide-over navigation and one-column content below 760px.

## Product principles

- Show observed patterns, never causal claims.
- Show an em dash or a setup state when a real value is unavailable.
- Keep the demo path short: overview → customer → prediction → diagnostics → action.
- Use motion only to communicate page/state transitions.