# SpendPrint AI 2.0

Predict. Diagnose. Optimize.

SpendPrint AI is a campaign intelligence workspace built around an existing response model. The frontend is intentionally honest: it never invents metrics, customer profiles, or predictions when the real artifacts are not present.

## Run the frontend

```bash
npm install
npm run dev
```

The Vite preview runs on port 5000 and allows proxied Replit hosts.

## Add the real model

Place the teammate's existing files in:

```text
model/model.pkl
model/features.pkl
model/metrics.json
ml/predict.py
data/marketing_campaign.csv
```

The FastAPI service in `backend/` is designed to discover those files without retraining or replacing them. The frontend calls only the API layer.

## Product flow

Customer data → Predict → Explain → Diagnose → Act

The UI contains Overview, Customer Intelligence, Campaign Diagnostics, Action Center, Model Intelligence, and Settings. Empty states are used until a real dataset and model are uploaded.