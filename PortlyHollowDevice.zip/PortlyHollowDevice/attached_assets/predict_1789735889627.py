
import joblib
import pandas as pd

# Load the trained model
model = joblib.load("model.pkl")

# Load the exact features used during training
features = joblib.load("features.pkl")


def predict_response(customer_data):

    # Convert customer data into a DataFrame
    df = pd.DataFrame([customer_data])

    # Keep the same features and same order as training
    df = df[features]

    # Get probability of Response = 1
    probability = float(model.predict_proba(df)[0][1])

    # Convert probability into binary prediction
    prediction = int(probability >= 0.50)

    # Demo priority thresholds
    if probability >= 0.70:
        priority = "HIGH"
    elif probability >= 0.40:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    return {
        "response_probability": probability,
        "prediction": prediction,
        "priority": priority
    }
