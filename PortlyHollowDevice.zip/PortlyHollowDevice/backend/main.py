from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.services.analytics_service import AnalyticsService
from backend.services.ml_service import MLService
from backend.services.supabase_service import SupabaseService

ROOT = Path(__file__).resolve().parents[1]
ml = MLService(ROOT)
analytics = AnalyticsService(ROOT)
database = SupabaseService()

app = FastAPI(title="SpendPrint AI 2.0 API", version="2.0.0", description="Campaign intelligence APIs backed by the supplied ML artifacts.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class ActionInput(BaseModel):
    observation: str = Field(min_length=3)
    hypothesis: str = Field(min_length=3)
    experiment: str = Field(min_length=3)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "artifacts": ml.artifacts, "dataset": analytics.available, "database": database.connected}


@app.get("/api/model/info")
def model_info() -> dict[str, Any]:
    return ml.get_info()


@app.get("/api/metrics")
def metrics() -> dict[str, Any]:
    return ml.get_metrics()


@app.get("/api/overview")
def overview() -> dict[str, Any]:
    summary = analytics.overview()
    summary["high_probability_customers"] = ml.count_high_probability(analytics.customers())
    return summary


@app.get("/api/customers")
def customers(search: str = Query(default="")) -> dict[str, Any]:
    items = analytics.customers(search)
    return {"items": items[:100], "total": len(items)}


@app.get("/api/customers/{customer_id}")
def customer(customer_id: str) -> dict[str, Any]:
    result = analytics.customer(customer_id)
    if not result:
        raise HTTPException(status_code=404, detail="Customer not found in the connected dataset.")
    return result


@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return ml.predict_customer(payload)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Prediction could not be completed: {exc}") from exc


@app.get("/api/diagnostics/products")
def products() -> dict[str, Any]:
    return {"items": analytics.product_signals()}


@app.get("/api/diagnostics/segments")
def segments() -> dict[str, Any]:
    return {"items": analytics.segment_signals()}


@app.get("/api/diagnostics/matrix")
def matrix() -> dict[str, Any]:
    return {"items": analytics.matrix()}


@app.get("/api/diagnostics/alerts")
def alerts() -> dict[str, Any]:
    return {"items": analytics.alerts()}


@app.get("/api/actions")
def actions() -> dict[str, Any]:
    return {"items": database.list_actions(), "persistent": database.connected}


@app.post("/api/actions")
def create_action(payload: ActionInput) -> dict[str, Any]:
    try:
        return database.create_action(payload.model_dump())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Action persistence is unavailable: {exc}") from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)