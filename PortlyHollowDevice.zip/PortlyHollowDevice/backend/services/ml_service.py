from __future__ import annotations

import importlib.util
import json
import pickle
from pathlib import Path
from typing import Any


class MLService:
    """Loads the supplied ML artifacts once and exposes honest model metadata."""

    def __init__(self, root: Path | None = None) -> None:
        self.root = root or Path(__file__).resolve().parents[2]
        self.model_path = self.root / "model" / "model.pkl"
        self.features_path = self.root / "model" / "features.pkl"
        self.metrics_path = self.root / "model" / "metrics.json"
        self.predict_path = self.root / "ml" / "predict.py"
        self.model: Any = None
        self.features: Any = None
        self.metrics: dict[str, Any] = {}
        self.predict_module: Any = None
        self.load_error: str | None = None
        self.reload()

    def reload(self) -> None:
        self.model = None
        self.features = None
        self.metrics = {}
        self.predict_module = None
        self.load_error = None
        try:
            if self.model_path.exists():
                self.model = self._load_pickle(self.model_path)
            if self.features_path.exists():
                self.features = self._load_pickle(self.features_path)
            if self.metrics_path.exists():
                self.metrics = json.loads(self.metrics_path.read_text())
            if self.predict_path.exists():
                spec = importlib.util.spec_from_file_location("spendprint_predict", self.predict_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    self.predict_module = module
        except Exception as exc:  # the API reports this instead of hiding it behind fake data
            self.load_error = f"{type(exc).__name__}: {exc}"

    @staticmethod
    def _load_pickle(path: Path) -> Any:
        try:
            import joblib

            return joblib.load(path)
        except ImportError:
            with path.open("rb") as handle:
                return pickle.load(handle)

    @property
    def artifacts(self) -> dict[str, bool]:
        return {
            "model": self.model_path.exists() and self.model is not None,
            "features": self.features_path.exists() and self.features is not None,
            "metrics": self.metrics_path.exists() and bool(self.metrics),
            "predict": self.predict_path.exists() and self.predict_module is not None,
        }

    @property
    def ready(self) -> bool:
        return self.model is not None

    def get_metrics(self) -> dict[str, Any]:
        return self.metrics

    def get_info(self) -> dict[str, Any]:
        info: dict[str, Any] = {
            "name": self.metrics.get("model") or (type(self.model).__name__ if self.model is not None else None),
            "target": self.metrics.get("target", "Response") if self.metrics else "Response",
            "version": self.metrics.get("model_version") or self.metrics.get("version"),
            "feature_count": len(self.feature_names()),
            "artifacts": self.artifacts,
            "available": self.ready,
        }
        if self.load_error:
            info["load_error"] = self.load_error
        importance = self.feature_importance()
        if importance:
            info["feature_importance"] = importance
        return info

    def feature_names(self) -> list[str]:
        if self.features is None:
            return []
        if isinstance(self.features, dict):
            for key in ("features", "feature_names", "columns", "names"):
                if isinstance(self.features.get(key), (list, tuple)):
                    return [str(x) for x in self.features[key]]
            return [str(k) for k in self.features.keys()]
        if isinstance(self.features, (list, tuple)):
            return [str(x) for x in self.features]
        if hasattr(self.features, "columns"):
            return [str(x) for x in self.features.columns]
        return []

    def predict_customer(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.ready:
            raise RuntimeError("ML artifacts are not available. Add model/model.pkl and model/features.pkl.")

        helper_result = self._call_prediction_helper(payload)
        if helper_result is not None:
            normalized = self._normalize_prediction(helper_result, payload)
            explanation = self.explain_prediction(payload)
            if explanation:
                normalized["explanation"] = explanation
            return normalized

        values = [payload.get(name) for name in self.feature_names()]
        model_input: Any = [values]
        try:
            import pandas as pd

            model_input = pd.DataFrame([payload])
            if self.feature_names():
                model_input = model_input.reindex(columns=self.feature_names())
        except ImportError:
            pass

        predicted = self.model.predict(model_input)
        probability = None
        if hasattr(self.model, "predict_proba"):
            probabilities = self.model.predict_proba(model_input)
            if len(probabilities[0]) > 1:
                probability = float(probabilities[0][1])
            else:
                probability = float(probabilities[0][0])
        result: dict[str, Any] = {
            "customer_id": payload.get("ID") or payload.get("id") or payload.get("customer_id"),
            "prediction": int(predicted[0]) if hasattr(predicted[0], "item") else predicted[0],
        }
        if probability is not None:
            result["response_probability"] = probability
            result["prediction_label"] = "Likely to respond" if probability >= 0.5 else "Unlikely to respond"
        return result

    def _call_prediction_helper(self, payload: dict[str, Any]) -> Any:
        if self.predict_module is None:
            return None
        for name in ("predict_response", "predict_customer", "predict", "run_prediction", "make_prediction"):
            helper = getattr(self.predict_module, name, None)
            if not callable(helper):
                continue
            try:
                if name == "predict_response":
                    return helper(payload, self.model, self.feature_names())
                return helper(payload)
            except TypeError:
                try:
                    return helper(**payload)
                except TypeError:
                    continue
        return None

    @staticmethod
    def _normalize_prediction(result: Any, payload: dict[str, Any]) -> dict[str, Any]:
        if isinstance(result, dict):
            normalized = dict(result)
        else:
            normalized = {"prediction": result}
        normalized.setdefault("customer_id", payload.get("ID") or payload.get("id") or payload.get("customer_id"))
        if "response_probability" in normalized and normalized["response_probability"] is not None:
            probability = float(normalized["response_probability"])
            normalized["response_probability"] = probability
            normalized.setdefault("prediction_label", "Likely to respond" if probability >= 0.5 else "Unlikely to respond")
        return normalized

    def feature_importance(self) -> list[dict[str, Any]]:
        model = self.model
        values = getattr(model, "feature_importances_", None)
        if values is None and hasattr(model, "named_steps"):
            classifier = model.named_steps.get("classifier")
            values = getattr(classifier, "coef_", None)
            if values is not None:
                values = values[0]
        if values is None:
            return []
        names = self.feature_names()
        return [
            {"feature": names[index] if index < len(names) else f"Feature {index + 1}", "importance": float(value)}
            for index, value in enumerate(values)
        ]

    def explain_prediction(self, payload: dict[str, Any]) -> list[dict[str, Any]]:
        """Return model contributions where a linear pipeline supports them."""
        if self.model is None or not hasattr(self.model, "named_steps"):
            return []
        steps = self.model.named_steps
        classifier = steps.get("classifier")
        if classifier is None or not hasattr(classifier, "coef_"):
            return []
        import pandas as pd

        names = self.feature_names()
        frame = pd.DataFrame([payload]).reindex(columns=names)
        transformed = steps["imputer"].transform(frame)
        transformed = steps["scaler"].transform(transformed)
        contributions = transformed[0] * classifier.coef_[0]
        ranked = sorted(enumerate(contributions), key=lambda item: abs(item[1]), reverse=True)[:6]
        return [
            {
                "feature": names[index],
                "value": payload.get(names[index]),
                "contribution": float(value),
                "direction": "positive" if value > 0 else "negative",
            }
            for index, value in ranked
        ]

    def count_high_probability(self, records: list[dict[str, Any]], threshold: float = 0.7) -> int | None:
        if not self.ready or not records:
            return None
        import pandas as pd

        frame = pd.DataFrame(records).reindex(columns=self.feature_names())
        frame = frame.apply(pd.to_numeric, errors="coerce")
        probabilities = self.model.predict_proba(frame)[:, 1]
        return int((probabilities >= threshold).sum())