from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any


class SupabaseService:
    """Optional persistence adapter. The app remains readable without credentials."""

    def __init__(self) -> None:
        self.client = None
        self.local_actions: list[dict[str, Any]] = []
        url, key = os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_ANON_KEY")
        if url and key:
            try:
                from supabase import create_client

                self.client = create_client(url, key)
            except Exception:
                self.client = None

    @property
    def connected(self) -> bool:
        return self.client is not None

    def list_actions(self) -> list[dict[str, Any]]:
        if self.client:
            try:
                response = self.client.table("actions").select("*").order("created_at", desc=True).execute()
                return response.data or []
            except Exception:
                return []
        return list(reversed(self.local_actions))

    def create_action(self, payload: dict[str, Any]) -> dict[str, Any]:
        action = {**payload, "created_at": datetime.now(timezone.utc).isoformat()}
        if self.client:
            response = self.client.table("actions").insert(action).execute()
            return (response.data or [action])[0]
        action["id"] = f"local-{len(self.local_actions) + 1}"
        self.local_actions.append(action)
        return action