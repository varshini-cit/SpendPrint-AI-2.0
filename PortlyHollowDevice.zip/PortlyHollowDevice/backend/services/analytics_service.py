from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path
from typing import Any


PRODUCT_COLUMNS = {
    "Wines": "MntWines",
    "Fruits": "MntFruits",
    "Meat": "MntMeatProducts",
    "Fish": "MntFishProducts",
    "Sweets": "MntSweetProducts",
    "Gold": "MntGoldProds",
}


class AnalyticsService:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root or Path(__file__).resolve().parents[2]
        self.dataset_path = self._find_dataset()
        self.rows: list[dict[str, str]] = []
        self._load()

    def _find_dataset(self) -> Path | None:
        data_dir = self.root / "data"
        if not data_dir.exists():
            return None
        preferred = data_dir / "marketing_campaign.csv"
        if preferred.exists():
            return preferred
        return next(data_dir.glob("*.csv"), None)

    def _load(self) -> None:
        if not self.dataset_path:
            return
        try:
            with self.dataset_path.open(newline="", encoding="utf-8-sig") as handle:
                first_line = handle.readline()
                delimiter = "\t" if "\t" in first_line else ","
                handle.seek(0)
                self.rows = list(csv.DictReader(handle, delimiter=delimiter))
        except (OSError, UnicodeError):
            self.rows = []

    @property
    def available(self) -> bool:
        return bool(self.rows)

    @staticmethod
    def _number(row: dict[str, str], key: str, default: float = 0) -> float:
        try:
            return float(str(row.get(key, "")).replace(",", "").strip())
        except (ValueError, TypeError):
            return default

    @staticmethod
    def _response(row: dict[str, str]) -> int | None:
        value = row.get("Response", row.get("response"))
        if value in (None, ""):
            return None
        try:
            return int(float(value))
        except ValueError:
            return None

    def customers(self, search: str = "") -> list[dict[str, Any]]:
        items = []
        for row in self.rows:
            customer_id = row.get("ID") or row.get("id") or row.get("customer_id")
            if search and search.lower() not in str(customer_id).lower():
                continue
            item = self._engineer_features(row)
            item["id"] = customer_id
            item["age"] = self._age(row)
            item["children"] = int(self._number(row, "Kidhome"))
            item["teens"] = int(self._number(row, "Teenhome"))
            item["recency"] = int(self._number(row, "Recency"))
            item["income"] = self._number(row, "Income") or None
            item["total_spend"] = sum(self._number(row, col) for col in PRODUCT_COLUMNS.values()) or None
            item["campaign_history"] = sum(self._number(row, f"AcceptedCmp{i}") for i in range(1, 6))
            item["channels"] = self._channels(row)
            items.append(item)
        return items

    def _engineer_features(self, row: dict[str, str]) -> dict[str, Any]:
        """Add the four derived fields required by the supplied features.pkl."""
        item: dict[str, Any] = dict(row)
        total_spend = sum(self._number(row, col) for col in PRODUCT_COLUMNS.values())
        total_purchases = sum(self._number(row, col) for col in ("NumWebPurchases", "NumCatalogPurchases", "NumStorePurchases"))
        deals = self._number(row, "NumDealsPurchases")
        digital_purchases = self._number(row, "NumWebPurchases") + self._number(row, "NumCatalogPurchases")
        item["TotalSpend"] = total_spend
        item["TotalPurchases"] = total_purchases
        item["DealRatio"] = deals / total_purchases if total_purchases else 0
        item["DigitalRatio"] = digital_purchases / total_purchases if total_purchases else 0
        return item

    def customer(self, customer_id: str) -> dict[str, Any] | None:
        found = self.customers(customer_id)
        return next((row for row in found if str(row.get("id")) == str(customer_id)), None)

    def product_signals(self) -> list[dict[str, Any]]:
        output = []
        for product, column in PRODUCT_COLUMNS.items():
            group = [row for row in self.rows if self._number(row, column) > 0 and self._response(row) is not None]
            responses = [self._response(row) for row in group]
            output.append({
                "product": product,
                "customers": len(group),
                "spend": round(sum(self._number(row, column) for row in group), 2),
                "observed_response_rate": round(sum(responses) / len(responses), 4) if responses else None,
            })
        return output

    def overview(self) -> dict[str, Any]:
        responses = [self._response(row) for row in self.rows if self._response(row) is not None]
        responded = sum(response == 1 for response in responses)
        did_not_respond = sum(response == 0 for response in responses)
        return {
            "customers_analyzed": len(self.rows),
            "responded": responded,
            "did_not_respond": did_not_respond,
            "observed_response_rate": round(responded / len(responses), 4) if responses else None,
        }

    def segment_signals(self) -> list[dict[str, Any]]:
        segments: list[tuple[str, str, list[dict[str, str]]]] = []
        age_groups: dict[str, list[dict[str, str]]] = defaultdict(list)
        for row in self.rows:
            age_groups[self._age_group(row)].append(row)
        segments.extend(("Age group", key, value) for key, value in age_groups.items())
        for key in ("Education", "Marital_Status"):
            groups: dict[str, list[dict[str, str]]] = defaultdict(list)
            for row in self.rows:
                groups[row.get(key, "Unknown") or "Unknown"].append(row)
            segments.extend((key.replace("_", " "), group, rows) for group, rows in groups.items())
        output = []
        for segment, value, rows in segments:
            responses = [self._response(row) for row in rows if self._response(row) is not None]
            output.append({"segment": segment, "value": value, "customers": len(rows), "observed_response_rate": round(sum(responses) / len(responses), 4) if responses else None})
        return output

    def matrix(self) -> list[dict[str, Any]]:
        cells = []
        segment_rows = [
            ("Younger", lambda r: self._age_group(r) == "Younger"),
            ("Graduation", lambda r: (r.get("Education") or "Unknown") == "Graduation"),
            ("No kids", lambda r: self._number(r, "Kidhome") + self._number(r, "Teenhome") == 0),
        ]
        for product, column in PRODUCT_COLUMNS.items():
            for label, selector in segment_rows:
                group = [r for r in self.rows if selector(r) and self._number(r, column) > 0 and self._response(r) is not None]
                responses = [self._response(r) for r in group]
                cells.append({"product": product, "segment": label, "count": len(group), "response_rate": round(sum(responses) / len(responses), 4) if responses else None})
        return cells

    def alerts(self) -> list[dict[str, Any]]:
        products = [item for item in self.product_signals() if item["observed_response_rate"] is not None]
        products.sort(key=lambda item: item["observed_response_rate"])
        return [
            {
                "title": f"Lower observed response for {item['product']}",
                "detail": "Observed response is lower for this product group. Consider a message or offer experiment.",
                "metric": f"{round(item['observed_response_rate'] * 100)}%",
                "severity": "watch",
            }
            for item in products[:3]
        ]

    def _age(self, row: dict[str, str]) -> int | None:
        birth_year = self._number(row, "Year_Birth")
        return int(2024 - birth_year) if birth_year else None

    def _age_group(self, row: dict[str, str]) -> str:
        age = self._age(row)
        if age is None:
            return "Unknown"
        if age < 35:
            return "Younger"
        if age < 55:
            return "Mid-career"
        return "Mature"

    @staticmethod
    def _channels(row: dict[str, str]) -> list[str]:
        channels = []
        for key, label in (("NumWebPurchases", "Web"), ("NumCatalogPurchases", "Catalog"), ("NumStorePurchases", "Store")):
            try:
                if float(row.get(key, 0)) > 0:
                    channels.append(label)
            except ValueError:
                pass
        return channels