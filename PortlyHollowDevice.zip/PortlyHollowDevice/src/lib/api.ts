export type ApiStatus = 'ready' | 'empty' | 'error'

export interface ApiResult<T> {
  data: T | null
  status: ApiStatus
  message?: string
}

const API_BASE = import.meta.env.VITE_API_URL || '/api'

async function request<T>(path: string, options?: RequestInit): Promise<ApiResult<T>> {
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
    })
    const body = await response.json().catch(() => ({}))
    if (!response.ok) {
      return { data: null, status: 'error', message: body.detail || `Request failed (${response.status})` }
    }
    return { data: body, status: 'ready' }
  } catch {
    return { data: null, status: 'error', message: 'Backend unavailable — start the API to connect live data.' }
  }
}

export const api = {
  health: () => request<{ status: string; artifacts: Record<string, boolean>; dataset: boolean }>('/health'),
  metrics: () => request<Record<string, unknown>>('/metrics'),
  overview: () => request<{ customers_analyzed: number; responded: number; did_not_respond: number; observed_response_rate?: number; high_probability_customers?: number | null }>('/overview'),
  modelInfo: () => request<Record<string, unknown>>('/model/info'),
  customers: (query = '') => request<{ items: Customer[]; total: number }>(`/customers${query ? `?search=${encodeURIComponent(query)}` : ''}`),
  customer: (id: string) => request<Customer>(`/customers/${encodeURIComponent(id)}`),
  predict: (payload: Record<string, unknown>) => request<Prediction>('/predict', { method: 'POST', body: JSON.stringify(payload) }),
  products: () => request<{ items: ProductSignal[] }>('/diagnostics/products'),
  segments: () => request<{ items: SegmentSignal[] }>('/diagnostics/segments'),
  matrix: () => request<{ items: MatrixCell[] }>('/diagnostics/matrix'),
  alerts: () => request<{ items: Alert[] }>('/diagnostics/alerts'),
  actions: () => request<{ items: Action[] }>('/actions'),
  createAction: (payload: Omit<Action, 'id' | 'created_at'>) => request<Action>('/actions', { method: 'POST', body: JSON.stringify(payload) }),
}

export interface Customer {
  id: string | number
  age?: number
  education?: string
  marital_status?: string
  income?: number
  children?: number
  teens?: number
  recency?: number
  total_spend?: number
  channels?: string[]
  campaign_history?: number
  [key: string]: unknown
}

export interface Prediction {
  customer_id?: string | number
  prediction?: number
  prediction_label?: string
  response_probability?: number
  model_version?: string
  priority?: string
  explanation?: { feature: string; value?: string | number; contribution?: number; direction?: string }[]
}

export interface ProductSignal {
  product: string
  observed_response_rate?: number
  customers?: number
  spend?: number
}
export interface SegmentSignal {
  segment: string
  value: string
  observed_response_rate?: number
  customers?: number
}
export interface MatrixCell {
  product: string
  segment: string
  response_rate?: number
  count?: number
}
export interface Alert {
  title: string
  detail: string
  metric?: string | number
  severity?: string
}
export interface Action {
  id?: string | number
  observation: string
  hypothesis: string
  experiment: string
  status?: string
  created_at?: string
}