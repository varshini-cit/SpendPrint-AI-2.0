import { useEffect, useMemo, useState } from 'react'
import {
  Activity, ArrowUpRight, BarChart3, BrainCircuit, Check, ChevronDown, CircleHelp,
  FlaskConical, Gauge, LayoutDashboard, Menu, Network, PanelLeftClose, Plus,
  Search, Settings, Sparkles, Target, Users, X, Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api, type Action, type Customer, type MatrixCell, type Prediction, type ProductSignal, type SegmentSignal } from './lib/api'

type Page = 'dashboard' | 'customers' | 'diagnostics' | 'actions' | 'model' | 'settings'

const nav = [
  { id: 'dashboard' as Page, label: 'Overview', icon: LayoutDashboard },
  { id: 'customers' as Page, label: 'Customer Intelligence', icon: Users },
  { id: 'diagnostics' as Page, label: 'Campaign Diagnostics', icon: Activity },
  { id: 'actions' as Page, label: 'Action Center', icon: FlaskConical },
  { id: 'model' as Page, label: 'Model Intelligence', icon: BrainCircuit },
]

const colors = ['#6757f4', '#14b8a6', '#f59e0b', '#ef6a88', '#93a4bc', '#2e8dd5']

function App() {
  const [page, setPage] = useState<Page>('dashboard')
  const [mobileNav, setMobileNav] = useState(false)
  const [health, setHealth] = useState<{ status: string; artifacts: Record<string, boolean>; dataset: boolean } | null>(null)

  useEffect(() => { api.health().then((result) => result.data && setHealth(result.data)) }, [])

  const go = (next: Page) => { setPage(next); setMobileNav(false) }
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><span>SP</span></div>
          <div><strong>SpendPrint</strong><small>AI 2.0</small></div>
          <button className="icon-btn sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18} /></button>
        </div>
        <div className="workspace-switcher">
          <div className="workspace-avatar">M</div>
          <div><b>Marketing workspace</b><span>Growth intelligence</span></div>
          <ChevronDown size={15} />
        </div>
        <nav className="nav-list">
          <span className="nav-label">Workspace</span>
          {nav.map((item) => {
            const Icon = item.icon
            return <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => go(item.id)}>
              <Icon size={18} strokeWidth={page === item.id ? 2.4 : 1.8} /><span>{item.label}</span>
              {item.id === 'actions' && <em>3</em>}
            </button>
          })}
          <span className="nav-label nav-label-spaced">System</span>
          <button className={`nav-item ${page === 'settings' ? 'active' : ''}`} onClick={() => go('settings')}><Settings size={18} /><span>Settings</span></button>
        </nav>
        <div className="sidebar-footer">
          <div className="system-mini"><span className="pulse-dot"></span><div><b>System status</b><small>{health?.status === 'ok' ? 'Connected and healthy' : 'Waiting for data connection'}</small></div></div>
          <div className="user-chip"><div className="user-avatar">VD</div><div><b>Campaign team</b><small>Product workspace</small></div><MoreDots /></div>
        </div>
      </aside>
      {mobileNav && <button className="mobile-backdrop" onClick={() => setMobileNav(false)} aria-label="Close navigation" />}
      <main className="main-content">
        <header className="topbar">
          <button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={20} /></button>
          <div className="breadcrumbs"><span>SpendPrint AI</span><span>/</span><b>{nav.find(n => n.id === page)?.label || 'Settings'}</b></div>
          <div className="topbar-actions"><div className="live-status"><span className="status-dot"></span>Live workspace</div><button className="icon-btn"><CircleHelp size={18} /></button><div className="top-avatar">VD</div></div>
        </header>
        <div className="page-wrap">
          {page === 'dashboard' && <Dashboard onNavigate={go} health={health} />}
          {page === 'customers' && <CustomerIntelligence />}
          {page === 'diagnostics' && <Diagnostics />}
          {page === 'actions' && <ActionCenter />}
          {page === 'model' && <ModelIntelligence health={health} />}
          {page === 'settings' && <SettingsPage health={health} />}
        </div>
      </main>
    </div>
  )
}

function MoreDots() { return <span className="more-dots">•••</span> }

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>
}

function StatusPill({ children, tone = 'muted' }: { children: React.ReactNode; tone?: 'muted' | 'green' | 'purple' | 'amber' }) {
  return <span className={`status-pill ${tone}`}><span className="pill-dot" />{children}</span>
}

function MetricCard({ label, value, detail, icon: Icon, tone = 'purple' }: { label: string; value: string; detail: string; icon: typeof Gauge; tone?: string }) {
  return <div className="metric-card"><div className={`metric-icon ${tone}`}><Icon size={19} /></div><div className="metric-copy"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div><ArrowUpRight className="metric-arrow" size={17} /></div>
}

function EmptyPanel({ title = 'Connect your data to unlock this view', detail = 'Real campaign metrics, predictions, and observations will appear here once the backend finds the uploaded dataset and trained artifacts.' }: { title?: string; detail?: string }) {
  return <div className="empty-panel"><div className="empty-orb"><Network size={24} /></div><div><b>{title}</b><p>{detail}</p></div><StatusPill>Not connected</StatusPill></div>
}

function Dashboard({ onNavigate, health }: { onNavigate: (p: Page) => void; health: { status: string; artifacts: Record<string, boolean>; dataset: boolean } | null }) {
  const [metrics, setMetrics] = useState<Record<string, unknown> | null>(null)
  const [overview, setOverview] = useState<{ customers_analyzed: number; responded: number; did_not_respond: number; observed_response_rate?: number; high_probability_customers?: number | null } | null>(null)
  const [products, setProducts] = useState<ProductSignal[]>([])
  useEffect(() => { api.metrics().then(r => r.data && setMetrics(r.data)); api.overview().then(r => r.data && setOverview(r.data)); api.products().then(r => r.data && setProducts(r.data.items || [])) }, [])
  const customerCount = overview?.customers_analyzed ? String(overview.customers_analyzed) : metricValue(metrics, ['customers_analyzed', 'customer_count'])
  const responseRate = overview?.observed_response_rate != null ? String(Math.round(overview.observed_response_rate * 100)) : metricValue(metrics, ['response_rate', 'observed_response_rate'])
  const roc = metricValue(metrics, ['roc_auc', 'roc-auc'])
  const formattedRoc = roc && Number.isFinite(Number(roc)) ? Number(roc).toFixed(3) : roc
  const hasData = Boolean(health?.dataset)
  const chartData = products.map((p) => ({ name: p.product, value: Math.round((p.observed_response_rate || 0) * 100) }))
  return <div className="animate-in">
    <PageHeader eyebrow="Campaign intelligence / overview" title="Predict. Diagnose. Optimize." description="Transform customer behavior into campaign intelligence." action={<button className="primary-btn" onClick={() => onNavigate('customers')}><Sparkles size={16} /> Explore a customer</button>} />
    {!hasData && <div className="notice-banner"><div className="notice-icon"><Zap size={17} /></div><div><b>Workspace is ready for your real ML artifacts</b><span>Add the trained model files and campaign dataset to activate live intelligence. This preview never invents metrics or predictions.</span></div><button onClick={() => onNavigate('settings')}>View setup <ArrowUpRight size={14} /></button></div>}
    <section className="metric-grid">
      <MetricCard label="Customers analyzed" value={customerCount || '—'} detail={hasData ? 'From connected dataset' : 'Awaiting dataset'} icon={Users} />
      <MetricCard label="Observed response rate" value={responseRate ? `${responseRate}%` : '—'} detail={hasData ? 'Observed, not causal' : 'Not available yet'} icon={Target} tone="teal" />
      <MetricCard label="High-probability customers" value={overview?.high_probability_customers != null ? String(overview.high_probability_customers) : '—'} detail={overview?.high_probability_customers != null ? 'Predicted ≥ 70% response' : 'Requires live predictions'} icon={Gauge} tone="amber" />
      <MetricCard label="Model ROC-AUC" value={formattedRoc || '—'} detail={roc ? 'From metrics.json' : 'Requires trained model'} icon={BrainCircuit} tone="pink" />
    </section>
    <div className="dashboard-grid">
      <section className="card response-card">
        <div className="card-heading"><div><span className="section-kicker">Observed campaign behavior</span><h2>Response overview</h2></div><StatusPill tone={hasData ? 'green' : 'muted'}>{hasData ? 'Live data' : 'Awaiting dataset'}</StatusPill></div>
        {hasData && overview && (overview.responded + overview.did_not_respond > 0) ? <div className="chart-area donut-layout"><ResponsiveContainer width="52%" height={190}><PieChart><Pie data={[{ name: 'Responded', value: overview.responded }, { name: 'Did not respond', value: overview.did_not_respond }]} innerRadius={64} outerRadius={86} paddingAngle={5} dataKey="value"><Cell fill="#6757f4" /><Cell fill="#e6eaf2" /></Pie><Tooltip /></PieChart></ResponsiveContainer><div className="legend"><div><span className="legend-color purple"></span><div><b>Responded</b><small>{overview.responded.toLocaleString()} observed customers</small></div></div><div><span className="legend-color pale"></span><div><b>Did not respond</b><small>{overview.did_not_respond.toLocaleString()} observed customers</small></div></div></div></div> : <EmptyPanel title="Response distribution is waiting on data" detail="The chart will use Response = 1 and Response = 0 from the uploaded campaign dataset." />}
      </section>
      <section className="card signals-card">
        <div className="card-heading"><div><span className="section-kicker">Observed category signals</span><h2>Product performance</h2></div><button className="text-btn" onClick={() => onNavigate('diagnostics')}>View diagnostics <ArrowUpRight size={14} /></button></div>
        {chartData.length ? <div className="chart-area"><ResponsiveContainer width="100%" height={210}><BarChart data={chartData} margin={{ left: -20, right: 6 }}><CartesianGrid vertical={false} stroke="#edf0f5" /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#8a96a8', fontSize: 11 }} /><YAxis axisLine={false} tickLine={false} tick={{ fill: '#8a96a8', fontSize: 11 }} unit="%" /><Tooltip /><Bar dataKey="value" radius={[5, 5, 0, 0]} fill="#14b8a6" /></BarChart></ResponsiveContainer></div> : <EmptyPanel title="Product signals will appear here" detail="Wines, fruits, meat, fish, sweets, and gold will be calculated from real observations." />}
      </section>
    </div>
    <section className="card intelligence-card">
      <div className="card-heading"><div><span className="section-kicker">What to do next</span><h2>Campaign intelligence feed</h2></div><button className="secondary-btn" onClick={() => onNavigate('actions')}><Plus size={16} /> Create experiment</button></div>
      <div className="feed-grid">{['Product signal', 'Segment signal', 'Opportunity signal'].map((kind) => <div className="feed-empty" key={kind}><div className="feed-icon"><Sparkles size={16} /></div><div><b>{kind}</b><p>Real observations will become actionable experiments here.</p></div><span>—</span></div>)}</div>
    </section>
  </div>
}

function CustomerIntelligence() {
  const [query, setQuery] = useState('')
  const [customers, setCustomers] = useState<Customer[]>([])
  const [selected, setSelected] = useState<Customer | null>(null)
  const [prediction, setPrediction] = useState<Prediction | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  useEffect(() => { api.customers().then(r => r.data && setCustomers(r.data.items || [])) }, [])
  const search = async () => { setError(''); const result = await api.customers(query); if (result.data) { setCustomers(result.data.items || []); setSelected(result.data.items?.[0] || null) } else setError(result.message || 'Could not search customers.') }
  const runPrediction = async () => {
    if (!selected) return
    setLoading(true); setError(''); setPrediction(null)
    const result = await api.predict(selected)
    setLoading(false)
    if (result.data) setPrediction(result.data); else setError(result.message || 'Prediction unavailable.')
  }
  return <div className="animate-in">
    <PageHeader eyebrow="Individual intelligence" title="Know who to reach next." description="Search a real customer and see how the response model reads their profile." />
    <div className="search-row"><div className="search-box"><Search size={18} /><input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && search()} placeholder="Search by customer ID" /><button onClick={search}>Search</button></div><button className="secondary-btn" onClick={() => customers[0] && setSelected(customers[0])} disabled={!customers.length}>Load demo customer</button><StatusPill tone={customers.length ? 'green' : 'muted'}>{customers.length ? `${customers.length} customers` : 'No dataset loaded'}</StatusPill></div>
    {error && <div className="inline-error"><X size={16} />{error}</div>}
    <div className="customer-grid">
      <section className="card customer-list-card"><div className="card-heading"><div><span className="section-kicker">Customer directory</span><h2>Profiles</h2></div><span className="muted-count">{customers.length}</span></div>
        {customers.length ? <div className="customer-list">{customers.map((customer, i) => <button className={`customer-row ${selected?.id === customer.id ? 'selected' : ''}`} onClick={() => { setSelected(customer); setPrediction(null) }} key={String(customer.id)}><div className="customer-initial">{String(customer.id).slice(-2)}</div><div><b>Customer {customer.id}</b><span>{customer.education || 'Profile ready'} · {customer.marital_status || 'Segment pending'}</span></div><ArrowUpRight size={15} /></button>)}</div> : <EmptyPanel title="Customer profiles are not available yet" detail="Once the dataset is present, search will use its real customer IDs." />}
      </section>
      <section className="card profile-card"><div className="card-heading"><div><span className="section-kicker">Selected profile</span><h2>{selected ? `Customer ${selected.id}` : 'Customer profile'}</h2></div>{selected && <StatusPill tone="green">Selected</StatusPill>}</div>
        {selected ? <><div className="profile-hero"><div className="profile-avatar">{String(selected.id).slice(-2)}</div><div><b>Customer {selected.id}</b><p>Profile attributes from the connected dataset.</p></div></div><div className="profile-details">{[['Age', selected.age], ['Education', selected.education], ['Marital status', selected.marital_status], ['Income', selected.income ? formatCurrency(selected.income) : undefined], ['Children', selected.children], ['Teen household', selected.teens], ['Recency', selected.recency ? `${selected.recency} days` : undefined], ['Total spend', selected.total_spend ? formatCurrency(selected.total_spend) : undefined]].map(([label, value]) => <div key={String(label)}><span>{label}</span><b>{value ?? 'Not available'}</b></div>)}</div><button className="primary-btn full-btn" onClick={runPrediction} disabled={loading}><BrainCircuit size={17} />{loading ? 'Running real model…' : 'Run response prediction'}</button></> : <EmptyPanel title="Select a customer to inspect" detail="The prediction card will call the FastAPI model endpoint with the selected profile." />}
      </section>
    </div>
    {prediction && <PredictionCard prediction={prediction} />}
  </div>
}

function PredictionCard({ prediction }: { prediction: Prediction }) {
  const probability = typeof prediction.response_probability === 'number' ? Math.round(prediction.response_probability * 100) : null
  return <section className="prediction-card"><div className="prediction-main"><div className="prediction-badge"><Sparkles size={16} /> AI response prediction</div><div className="probability">{probability !== null ? `${probability}%` : '—'}</div><b className="prediction-label">{prediction.prediction_label || 'Result returned by model'}</b><p>This is the model’s predicted response probability. It is not a causal explanation of customer behavior.</p><div className="prediction-pills"><StatusPill tone="purple">{prediction.priority ? `${prediction.priority} priority` : 'Priority not available'}</StatusPill><StatusPill>{prediction.model_version || 'Model version not available'}</StatusPill></div></div><div className="explanation"><div className="card-heading"><div><span className="section-kicker">Model explanation</span><h2>Factors contributing to this prediction</h2></div></div>{prediction.explanation?.length ? prediction.explanation.map((item) => <div className="factor" key={item.feature}><div className={`factor-sign ${item.contribution && item.contribution > 0 ? 'positive' : 'negative'}`}>{item.contribution && item.contribution > 0 ? '+' : '−'}</div><div><b>{item.feature}</b><span>{item.value !== undefined ? String(item.value) : 'Contribution available'}</span></div><strong>{item.contribution !== undefined ? item.contribution.toFixed(2) : '—'}</strong></div>) : <div className="subtle-empty">The connected model did not provide feature-level explanation for this prediction.</div>}</div></section>
}

function Diagnostics() {
  const [products, setProducts] = useState<ProductSignal[]>([])
  const [segments, setSegments] = useState<SegmentSignal[]>([])
  const [matrix, setMatrix] = useState<MatrixCell[]>([])
  useEffect(() => { api.products().then(r => r.data && setProducts(r.data.items || [])); api.segments().then(r => r.data && setSegments(r.data.items || [])); api.matrix().then(r => r.data && setMatrix(r.data.items || [])) }, [])
  const segmentGroups = [...new Set(matrix.map(s => s.segment))].slice(0, 5)
  return <div className="animate-in"><PageHeader eyebrow="Observed patterns" title="Find the campaign gaps." description="Diagnose where observed response is lower, then turn those signals into testable action." action={<div className="filter-compact"><span>View</span><button>All segments <ChevronDown size={14} /></button></div>} />
    <div className="diagnostic-grid">
      <section className="card wide-card"><div className="card-heading"><div><span className="section-kicker">Product performance</span><h2>Observed response by product</h2></div><StatusPill>{products.length ? 'Live data' : 'No data'}</StatusPill></div>{products.length ? <div className="product-rows">{products.map((p, i) => <div className="product-row" key={p.product}><div className="product-name"><span className="product-dot" style={{ background: colors[i % colors.length] }}></span><b>{p.product}</b></div><div className="bar-track"><span style={{ width: `${Math.min(100, (p.observed_response_rate || 0) * 100)}%`, background: colors[i % colors.length] }} /></div><strong>{p.observed_response_rate !== undefined ? `${Math.round(p.observed_response_rate * 100)}%` : '—'}</strong><small>{p.customers ?? '—'} customers</small></div>)}</div> : <EmptyPanel title="Product diagnostics are waiting on the dataset" detail="Observed response is calculated from campaign outcomes; no product signal is shown without data." />}</section>
      <section className="card alert-card"><div className="card-heading"><div><span className="section-kicker">Opportunity signals</span><h2>What needs attention</h2></div><Zap size={18} className="amber-icon" /></div><div className="alert-empty"><div className="alert-orb"><Target size={21} /></div><b>{products.length ? 'Review the lowest observed signals' : 'No signals yet'}</b><p>{products.length ? 'Use observed patterns as hypotheses — not guarantees.' : 'Alerts will be generated from real low-response patterns.'}</p></div></section>
    </div>
    <section className="card wide-card segment-card"><div className="card-heading"><div><span className="section-kicker">Audience view</span><h2>Customer segments</h2></div><button className="text-btn">Filter segments <ChevronDown size={14} /></button></div>{segments.length ? <div className="segment-table"><div className="table-head"><span>Segment</span><span>Value</span><span>Customers</span><span>Observed response</span></div>{segments.slice(0, 8).map(s => <div className="table-row" key={`${s.segment}-${s.value}`}><b>{s.segment}</b><span>{s.value}</span><span>{s.customers ?? '—'}</span><strong>{s.observed_response_rate !== undefined ? `${Math.round(s.observed_response_rate * 100)}%` : '—'}</strong></div>)}</div> : <EmptyPanel title="Segment analysis is not available yet" detail="Age, education, household, spend, and channel segments will be derived from real rows." />}</section>
    <section className="card wide-card heatmap-card"><div className="card-heading"><div><span className="section-kicker">Cross-signal view</span><h2>Product × segment response</h2></div><span className="heatmap-note">Observed response rate</span></div>{matrix.length ? <div className="heatmap"><div className="heat-head"><span></span>{segmentGroups.map(g => <b key={g}>{g}</b>)}</div>{[...new Set(matrix.map(m => m.product))].map(product => <div className="heat-row" key={product}><b>{product}</b>{segmentGroups.map(segment => { const cell = matrix.find(m => m.product === product && m.segment === segment); const rate = cell?.response_rate || 0; return <span key={segment} style={{ background: `rgba(103, 87, 244, ${Math.max(.08, rate)})` }} title={`${product} / ${segment}: ${Math.round(rate * 100)}%`}>{cell ? `${Math.round(rate * 100)}%` : '—'}</span> })}</div>)}</div> : <EmptyPanel title="Heatmap needs both product and segment data" detail="The matrix will show observed rates and remains blank until real dataset rows are available." />}</section>
  </div>
}

function ActionCenter() {
  const [actions, setActions] = useState<Action[]>([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ observation: '', hypothesis: '', experiment: '' })
  const [saving, setSaving] = useState(false)
  useEffect(() => { api.actions().then(r => r.data && setActions(r.data.items || [])) }, [])
  const create = async () => { if (!form.observation || !form.hypothesis || !form.experiment) return; setSaving(true); const result = await api.createAction(form); setSaving(false); if (result.data) { setActions([result.data, ...actions]); setForm({ observation: '', hypothesis: '', experiment: '' }); setShowForm(false) } }
  return <div className="animate-in"><PageHeader eyebrow="From insight to experiment" title="Make the next move measurable." description="Turn observed campaign patterns into thoughtful, testable actions." action={<button className="primary-btn" onClick={() => setShowForm(v => !v)}><Plus size={16} /> Create experiment</button>} />
    <div className="workflow-strip"><div><span>01</span><b>Observation</b><small>What the data shows</small></div><ArrowUpRight size={17} /><div><span>02</span><b>Hypothesis</b><small>What might explain it</small></div><ArrowUpRight size={17} /><div><span>03</span><b>Experiment</b><small>What to test next</small></div></div>
    {showForm && <section className="card form-card"><div className="card-heading"><div><span className="section-kicker">New campaign experiment</span><h2>Document a testable action</h2></div><button className="icon-btn" onClick={() => setShowForm(false)}><X size={18} /></button></div><div className="form-grid">{[['observation', 'Observed signal', 'Response is lower for…'], ['hypothesis', 'Why it might matter', 'The segment may respond to…'], ['experiment', 'Test this', 'Experiment with…']].map(([key, label, placeholder]) => <label key={key}><span>{label}</span><textarea value={form[key as keyof typeof form]} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={placeholder} /></label>)}</div><div className="form-actions"><button className="secondary-btn" onClick={() => setShowForm(false)}>Cancel</button><button className="primary-btn" onClick={create} disabled={saving}>{saving ? 'Saving…' : 'Save experiment'}</button></div></section>}
    <section className="action-grid">{actions.length ? actions.map((action, i) => <ActionCard key={String(action.id || i)} action={action} />) : <div className="card action-empty"><div className="empty-orb"><FlaskConical size={23} /></div><h2>No experiments saved yet</h2><p>Create an action from a real observation to start building your campaign learning loop.</p><button className="secondary-btn" onClick={() => setShowForm(true)}><Plus size={16} /> Create first experiment</button></div>}</section>
  </div>
}
function ActionCard({ action }: { action: Action }) {
  return <article className="card action-card"><div className="action-card-top"><StatusPill tone="purple">Experiment</StatusPill><span>{action.created_at ? new Date(action.created_at).toLocaleDateString() : 'Saved action'}</span></div><div className="action-step"><span>Observation</span><p>{action.observation}</p></div><div className="action-step"><span>Hypothesis</span><p>{action.hypothesis}</p></div><div className="action-step"><span>Experiment</span><p>{action.experiment}</p></div></article>
}

function ModelIntelligence({ health }: { health: { status: string; artifacts: Record<string, boolean>; dataset: boolean } | null }) {
  const [info, setInfo] = useState<Record<string, unknown> | null>(null)
  const [metrics, setMetrics] = useState<Record<string, unknown> | null>(null)
  useEffect(() => { api.modelInfo().then(r => r.data && setInfo(r.data)); api.metrics().then(r => r.data && setMetrics(r.data)) }, [])
  const modelReady = Boolean(health?.artifacts?.model && health?.artifacts?.features)
  const pipelineSteps: [string, LucideIcon][] = [['Customer data', Users], ['Feature processing', Network], ['Trained model', BrainCircuit], ['Response probability', Gauge], ['Campaign action', FlaskConical]]
  const importance = Array.isArray(info?.feature_importance) ? info.feature_importance as { feature: string; importance: number }[] : []
  return <div className="animate-in"><PageHeader eyebrow="Trust & transparency" title="See how the model thinks." description="A clear view of the trained model, its performance, and its route to campaign action." />
    <div className="model-overview-grid"><section className="card model-identity"><div className="model-logo"><BrainCircuit size={24} /></div><div><span className="section-kicker">Model overview</span><h2>{String(info?.name || 'Trained response model')}</h2><p>{modelReady ? 'Connected to the uploaded model artifacts.' : 'Model artifacts have not been added to this workspace.'}</p></div><StatusPill tone={modelReady ? 'green' : 'muted'}>{modelReady ? 'Connected' : 'Not connected'}</StatusPill><div className="identity-specs"><div><span>Target</span><b>{String(info?.target || 'Response')}</b></div><div><span>Features</span><b>{String(info?.feature_count || '—')}</b></div><div><span>Version</span><b>{String(info?.version || '—')}</b></div></div></section><section className="card metrics-card"><div className="card-heading"><div><span className="section-kicker">Model performance</span><h2>Validation metrics</h2></div><Gauge size={19} className="muted-icon" /></div><div className="model-metrics">{[['Accuracy', 'accuracy'], ['Precision', 'precision'], ['Recall', 'recall'], ['F1', 'f1'], ['ROC-AUC', 'roc_auc']].map(([label, key]) => <div key={key}><span>{label}</span><b>{formatMetric(metrics?.[key])}</b></div>)}</div></section></div>
    <div className="pipeline-card card"><div className="card-heading"><div><span className="section-kicker">Inference pipeline</span><h2>From customer behavior to action</h2></div></div><div className="pipeline">{pipelineSteps.map(([label, Icon], i) => <div className="pipeline-node" key={label}><div className={`pipeline-icon ${i === 2 ? 'highlight' : ''}`}><Icon size={20} /></div><b>{label}</b>{i < 4 && <div className="pipeline-line"><ArrowUpRight size={14} /></div>}</div>)}</div></div>
    <div className="model-bottom-grid"><section className="card"><div className="card-heading"><div><span className="section-kicker">Feature transparency</span><h2>Feature importance</h2></div></div>{importance.length ? <div className="importance-list">{importance.slice().sort((a, b) => Math.abs(b.importance) - Math.abs(a.importance)).slice(0, 8).map(item => <div className="importance-row" key={item.feature}><span>{item.feature}</span><div className="importance-track"><i style={{ width: `${Math.min(100, Math.abs(item.importance) * 100)}%` }} /></div><b>{item.importance.toFixed(2)}</b></div>)}</div> : <EmptyPanel title="Feature importance will appear when available" detail="SpendPrint will show the model-provided importance values without implying causality." />}</section><section className="card"><div className="card-heading"><div><span className="section-kicker">Quality check</span><h2>Confusion matrix</h2></div></div><div className="matrix-placeholder"><div><span>Actual positive</span><b>—</b></div><div><span>Actual negative</span><b>—</b></div><p>Metrics are read directly from metrics.json.</p></div></section></div>
  </div>
}

function SettingsPage({ health }: { health: { status: string; artifacts: Record<string, boolean>; dataset: boolean } | null }) {
  const checks = [{ label: 'Backend API', ready: health?.status === 'ok' }, { label: 'Campaign dataset', ready: health?.dataset }, { label: 'model.pkl', ready: health?.artifacts?.model }, { label: 'features.pkl', ready: health?.artifacts?.features }, { label: 'metrics.json', ready: health?.artifacts?.metrics }, { label: 'Supabase persistence', ready: false }]
  return <div className="animate-in"><PageHeader eyebrow="Workspace configuration" title="Keep the system legible." description="A lightweight health view for the pieces powering SpendPrint AI." /><section className="card settings-card"><div className="settings-intro"><div className="brand-mark large"><span>SP</span></div><div><span className="section-kicker">SpendPrint AI 2.0</span><h2>System health</h2><p>Model files and a real campaign dataset are intentionally required for live intelligence.</p></div></div><div className="health-list">{checks.map(check => <div className="health-row" key={check.label}><div className={`health-check ${check.ready ? 'ready' : ''}`}>{check.ready ? <Check size={15} /> : <span>—</span>}</div><b>{check.label}</b><StatusPill tone={check.ready ? 'green' : 'muted'}>{check.ready ? 'Connected' : 'Not configured'}</StatusPill></div>)}</div></section><section className="card setup-card"><div className="setup-icon"><CircleHelp size={20} /></div><div><h2>How to activate the workspace</h2><p>Place the existing trained artifacts in <code>model/</code>, the existing prediction helper in <code>ml/predict.py</code>, and the campaign CSV in <code>data/</code>. The backend will discover them without retraining or replacing the model.</p></div></section></div>
}

function metricValue(metrics: Record<string, unknown> | null, keys: string[]) { for (const key of keys) if (metrics?.[key] !== undefined && metrics?.[key] !== null) return String(metrics[key]); return '' }
function formatMetric(value: unknown) { return typeof value === 'number' ? value.toFixed(3) : value ? String(value) : '—' }
function formatCurrency(value: number) { return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value) }

export default App