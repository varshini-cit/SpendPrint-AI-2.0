---
name: Python runtime setup
description: Environment-specific setup needed to install and run the FastAPI backend.
---

Use the managed Python 3.11 toolchain for backend dependencies in this project. The system Python 3.13 environment is externally managed and rejects package installation.

**Why:** Installing FastAPI into the system interpreter failed under the immutable Nix environment, while the managed 3.11 toolchain installed the dependencies successfully.

**How to apply:** Keep backend dependencies in `requirements.txt`, and use the managed Python 3.11 runtime for workflow commands and package installation.