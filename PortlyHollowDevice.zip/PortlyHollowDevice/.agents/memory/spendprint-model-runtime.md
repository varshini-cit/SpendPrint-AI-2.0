---
name: SpendPrint model runtime
description: Compatibility and input-shape constraints for the supplied SpendPrint response model.
---

The supplied serialized model is a scikit-learn 1.6.1 pipeline with median imputation, standard scaling, and balanced logistic regression. It expects 20 numeric features, including TotalSpend, TotalPurchases, DealRatio, and DigitalRatio derived from the raw campaign columns.

**Why:** Newer scikit-learn versions produced a deserialization/runtime error in the saved SimpleImputer, and raw CSV rows do not contain the four derived fields.

**How to apply:** Keep scikit-learn pinned to 1.6.1 and derive the four fields before calling the model, preserving the exact order from features.pkl.