
from pathlib import Path

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]

model = None
features = None


def _load_artifacts():
    global model, features
    if model is None:
        model = joblib.load(BASE_DIR / "model" / "model.pkl")
    if features is None:
        features = joblib.load(BASE_DIR / "model" / "features.pkl")
    return model, features


def predict_response(customer_data, model_override=None, features_override=None):
    active_model, active_features = model_override, features_override
    if active_model is None or active_features is None:
        active_model, active_features = _load_artifacts()

    # Convert customer data into a DataFrame
    df = pd.DataFrame([customer_data])

    # Keep the same features and same order as training
    df = df[active_features]

    # Get probability of Response = 1
    probability = float(active_model.predict_proba(df)[0][1])

    # Convert probability into binary prediction
    prediction = int(probability >= 0.50)

    # Demo priority thresholds
    if probability >= 0.70:
        priority = "HIGH"
    elif probability >= 0.40:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    return {
        "response_probability": probability,
        "prediction": prediction,
        "priority": priority
    }

from pathlib import Path

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]

model = None
features = None


def _load_artifacts():
    global model, features
    if model is None:
        model = joblib.load(BASE_DIR / "model" / "model.pkl")
    if features is None:
        features = joblib.load(BASE_DIR / "model" / "features.pkl")
    return model, features


def predict_response(customer_data, model_override=None, features_override=None):
    active_model, active_features = model_override, features_override
    if active_model is None or active_features is None:
        active_model, active_features = _load_artifacts()

    # Convert customer data into a DataFrame
    df = pd.DataFrame([customer_data])

    # Keep the same features and same order as training
    df = df[active_features]

    # Get probability of Response = 1
    probability = float(active_model.predict_proba(df)[0][1])

    # Convert probability into binary prediction
    prediction = int(probability >= 0.50)

    # Demo priority thresholds
    if probability >= 0.70:
        priority = "HIGH"
    elif probability >= 0.40:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    return {
        "response_probability": probability,
        "prediction": prediction,
        "priority": priority
    }

from pathlib import Path

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]

model = None
features = None


def _load_artifacts():
    global model, features
    if model is None:
        model = joblib.load(BASE_DIR / "model" / "model.pkl")
    if features is None:
        features = joblib.load(BASE_DIR / "model" / "features.pkl")
    return model, features


def predict_response(customer_data, model_override=None, features_override=None):
    active_model, active_features = model_override, features_override
    if active_model is None or active_features is None:
        active_model, active_features = _load_artifacts()

    # Convert customer data into a DataFrame
    df = pd.DataFrame([customer_data])

    # Keep the same features and same order as training
    df = df[active_features]

    # Get probability of Response = 1
    probability = float(active_model.predict_proba(df)[0][1])

    # Convert probability into binary prediction
    prediction = int(probability >= 0.50)

    # Demo priority thresholds
    if probability >= 0.70:
        priority = "HIGH"
    elif probability >= 0.40:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    return {
        "response_probability": probability,
        "prediction": prediction,
        "priority": priority
    }

from pathlib import Path

import joblib
import pandas as pd

BASE_DIR = Path(__file__).resolve().parents[1]

model = None
features = None


def _load_artifacts():
    global model, features
    if model is None:
        model = joblib.load(BASE_DIR / "model" / "model.pkl")
    if features is None:
        features = joblib.load(BASE_DIR / "model" / "features.pkl")
    return model, features


def predict_response(customer_data, model_override=None, features_override=None):
    active_model, active_features = model_override, features_override
    if active_model is None or active_features is None:
        active_model, active_features = _load_artifacts()

    # Convert customer data into a DataFrame
    df = pd.DataFrame([customer_data])

    # Keep the same features and same order as training
    df = df[active_features]

    # Get probability of Response = 1
    probability = float(active_model.predict_proba(df)[0][1])

    # Convert probability into binary prediction
    prediction = int(probability >= 0.50)

    # Demo priority thresholds
    if probability >= 0.70:
        priority = "HIGH"
    elif probability >= 0.40:
        priority = "MEDIUM"
    else:
        priority = "LOW"

    return {
        "response_probability": probability,
        "prediction": prediction,
        "priority": priority
    }
